================================================================================
resoFlow - Publication Plots Export
================================================================================
Analysis Name   : Special Analysis 100%
Analysis ID     : single_step
Analysis Type   : CEST
Color Scheme    : Emerald Green (emerald_green)
Export Date     : 2026-09-08 16:46:18 UTC
resoFlow Version: 2026.2.0
ChemEx Version  : 2026.6.1

CONTENTS & STRUCTURE:
--------------------------------------------------------------------------------
This archive contains publication-grade figures exported in two formats:
  - png/ : 300 DPI high-resolution raster images (ideal for slides, preprints, and web)
  - pdf/ : Publication-grade vector PDF figures (ideal for manuscript submissions)

DIRECTORY OVERVIEW:
  - residues/   : Dispersion profile curves, normalized residuals strips, and composite figures.
  - kinetics/   : 2D kinetic correlation likelihood surfaces and confidence contours.
  - statistics/ : Parameter marginal error distribution histograms and correlation matrices.
  - grid_1d/    : 1D parameter likelihood scanning profiles with 1-sigma and 2-sigma thresholds.

Total Unique Figures Exported: 5 (5 PNGs + 5 PDFs = 10 files)
================================================================================
